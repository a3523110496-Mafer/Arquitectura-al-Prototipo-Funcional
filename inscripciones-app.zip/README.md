# inscripciones-app

Proyecto monorepo Next.js (App Router) con un microservicio de inscripciones simulado, API Gateway y frontend.

## Requisitos
- Node.js >= 18
- npm

## Instalación y ejecución (local)

```bash
# instalar dependencias
npm install

# generar cliente Prisma
npx prisma generate

# crear la BD y aplicar migración (esto abrirá un prompt, acepta)
npx prisma migrate dev --name init

# o si prefieres, crear la BD sin migraciones:
# npx prisma db push

# ejecutar en modo desarrollo
npm run dev
```

Abre http://localhost:3000

## Qué incluye
- Frontend (App Router):
  - `/app/page.tsx` : formulario para crear inscripciones
  - `/app/inscripciones/page.tsx` : lista de inscripciones
  - `/app/inscripciones/[id]/page.tsx` : detalle de una inscripción
- API:
  - `/app/api/inscripciones/route.ts` : microservicio de inscripciones (CRUD básico)
  - `/app/api/gateway/inscripciones/route.ts` : API Gateway que proxy a microservicio (simulado)
- Prisma + SQLite: `prisma/schema.prisma`

## Notas
- La primera vez ejecuta `npx prisma migrate dev --name init` para crear `prisma/dev.db`.
- Si prefieres no usar migraciones, puedes usar `npx prisma db push` para sincronizar el esquema.
