import { notFound } from 'next/navigation'
import Link from 'next/link'

async function getInscripcion(id: string) {
  const res = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL || ''}/api/inscripciones/${id}`, { cache: 'no-store' })
  if (!res.ok) return null
  return res.json()
}

export default async function InscripcionPage({ params }: { params: { id: string } }) {
  const inscripcion = await getInscripcion(params.id)
  if (!inscripcion) return notFound()

  return (
    <main style={{ padding: 24, fontFamily: 'Arial, sans-serif' }}>
      <h1>Inscripción</h1>
      <p><Link href="/inscripciones">Volver a la lista</Link></p>
      <dl>
        <dt>ID</dt><dd>{inscripcion.id}</dd>
        <dt>Nombre</dt><dd>{inscripcion.nombre}</dd>
        <dt>Matrícula</dt><dd>{inscripcion.matricula}</dd>
        <dt>Carrera</dt><dd>{inscripcion.carrera}</dd>
        <dt>Creado</dt><dd>{new Date(inscripcion.createdAt).toLocaleString()}</dd>
      </dl>
    </main>
  )
}
