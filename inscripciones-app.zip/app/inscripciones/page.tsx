import Link from 'next/link'

async function getInscripciones() {
  const res = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL || ''}/api/inscripciones`, { cache: 'no-store' })
  if (!res.ok) return []
  return res.json()
}

export default async function InscripcionesPage() {
  const inscripciones = await getInscripciones()

  return (
    <main style={{ padding: 24, fontFamily: 'Arial, sans-serif' }}>
      <h1>Lista de Inscripciones</h1>
      <p><a href="/">Volver al formulario</a></p>
      <table border={1} cellPadding={8} style={{ borderCollapse: 'collapse', marginTop: 12 }}>
        <thead>
          <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Matrícula</th>
            <th>Carrera</th>
            <th>Creado</th>
          </tr>
        </thead>
        <tbody>
          {inscripciones.length === 0 && (
            <tr><td colSpan={5}>No hay inscripciones</td></tr>
          )}
          {inscripciones.map((i: any) => (
            <tr key={i.id}>
              <td><Link href={`/inscripciones/${i.id}`}>{i.id}</Link></td>
              <td>{i.nombre}</td>
              <td>{i.matricula}</td>
              <td>{i.carrera}</td>
              <td>{new Date(i.createdAt).toLocaleString()}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </main>
  )
}
