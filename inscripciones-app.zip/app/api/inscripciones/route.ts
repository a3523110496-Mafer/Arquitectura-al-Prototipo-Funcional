import { NextResponse } from 'next/server'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export async function GET() {
  const list = await prisma.inscripcion.findMany({ orderBy: { createdAt: 'desc' } })
  return NextResponse.json(list)
}

export async function POST(request: Request) {
  const body = await request.json()
  const { nombre, matricula, carrera } = body
  if (!nombre || !matricula || !carrera) {
    return NextResponse.json({ error: 'Faltan campos' }, { status: 400 })
  }
  const nueva = await prisma.inscripcion.create({
    data: { nombre, matricula, carrera },
  })
  return NextResponse.json(nueva, { status: 201 })
}
