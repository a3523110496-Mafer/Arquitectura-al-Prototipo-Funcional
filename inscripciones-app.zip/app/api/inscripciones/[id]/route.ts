import { NextResponse } from 'next/server'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export async function GET(request: Request, { params }: { params: { id: string } }) {
  const id = params.id
  const item = await prisma.inscripcion.findUnique({ where: { id } })
  if (!item) return NextResponse.json({ error: 'No encontrada' }, { status: 404 })
  return NextResponse.json(item)
}
