'use client'

import { useState } from 'react'

export default function Home() {
  const [nombre, setNombre] = useState('')
  const [matricula, setMatricula] = useState('')
  const [carrera, setCarrera] = useState('')
  const [mensaje, setMensaje] = useState('')

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const res = await fetch('/api/gateway/inscripciones', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nombre, matricula, carrera }),
      })
      const data = await res.json()
      if (res.ok) {
        setMensaje(`Inscripción creada con ID: ${data.id}`)
        setNombre('')
        setMatricula('')
        setCarrera('')
      } else {
        setMensaje(data.error || 'Error al crear la inscripción')
      }
    } catch (err) {
      setMensaje('Error de conexión')
    }
  }

  return (
    <main style={{ padding: 24, fontFamily: 'Arial, sans-serif' }}>
      <h1>Formulario de Inscripción</h1>
      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 8, maxWidth: 480 }}>
        <input placeholder="Nombre" value={nombre} onChange={(e) => setNombre(e.target.value)} required />
        <input placeholder="Matrícula" value={matricula} onChange={(e) => setMatricula(e.target.value)} required />
        <input placeholder="Carrera" value={carrera} onChange={(e) => setCarrera(e.target.value)} required />
        <button type="submit">Enviar</button>
      </form>
      {mensaje && <p style={{ marginTop: 12 }}>{mensaje}</p>}
      <p style={{ marginTop: 12 }}>
        <a href="/inscripciones">Ver inscripciones</a>
      </p>
    </main>
  )
}
